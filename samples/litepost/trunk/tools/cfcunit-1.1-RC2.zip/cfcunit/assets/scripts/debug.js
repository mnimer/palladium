//==================================================================
function debug_toggleContents(source)
{
	var switchToState = debug_toggleSource(source);
	var container = source.parentNode;
	var i = 0;
	
	for(i=1; i<container.childNodes.length; i++)
	{
		target = container.childNodes[i];
		if(target.style)
			debug_toggleTarget(target, switchToState);
	}
}

//==================================================================
function debug_toggleSource(source)
{
	if(source.style.fontStyle == 'italic')
	{
		source.style.fontStyle = 'normal';
		source.title = 'click to collapse';
		return 'open';
	}
	else
	{
		source.style.fontStyle = 'italic';
		source.title = 'click to expand';
		return 'closed';
	}
}

//==================================================================
function debug_toggleTarget (target, switchToState)
{
	if(switchToState == 'open')
		target.style.display = '';
	else
		target.style.display = 'none';
}